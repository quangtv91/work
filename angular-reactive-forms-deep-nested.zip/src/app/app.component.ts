import { Component } from "@angular/core";
import { FormBuilder, FormGroup, FormArray } from "@angular/forms";

@Component({
  selector: "my-app",
  templateUrl: "./app.component.html",
  styleUrls: ["./app.component.css"]
})
export class AppComponent {

  myForm: FormGroup;

  constructor(private fb: FormBuilder) {
    this.myForm = this.fb.group({
      companies: this.fb.array([this.setCompanies()])
    });
  }

  addNewCompany() {
    let control = <FormArray>this.myForm.controls.companies;
    control.push(this.setCompanies());
  }

  deleteCompany(index) {
    let control = <FormArray>this.myForm.controls.companies;
    control.removeAt(index);
  }

  addNewProject(control) {
    control.push(this.setProjects());
  }

  deleteProject(control, index) {
    control.removeAt(index);
  }

  setCompanies() {
    return this.fb.group({
      company: [""],
      projects: this.fb.array([this.setProjects()])
    });
  }

  setProjects() {
    return this.fb.group({
      projectName: [""]
    });
  }
}
